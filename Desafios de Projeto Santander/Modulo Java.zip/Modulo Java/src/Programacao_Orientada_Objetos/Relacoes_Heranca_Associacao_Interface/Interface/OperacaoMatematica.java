package Programacao_Orientada_Objetos.Relacoes_Heranca_Associacao_Interface.Interface;

public interface OperacaoMatematica {

    void soma(double operando1, double operando2);

    void subtracao(double operando1, double operando2);

    void multiplicacao(double operando1, double operando2);

    void divisao(double operando1, double operando2);
}
