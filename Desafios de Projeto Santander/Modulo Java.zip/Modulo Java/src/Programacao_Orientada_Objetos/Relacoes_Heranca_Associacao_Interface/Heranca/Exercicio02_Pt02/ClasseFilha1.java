package Programacao_Orientada_Objetos.Relacoes_Heranca_Associacao_Interface.Heranca.Exercicio02_Pt02;

public class ClasseFilha1 extends ClasseMae{

    @Override // Realizando Sobrescrita
    void metodo1() {
        System.out.println("Método 1 da Classe Filha 1");
    }
}
