package Programacao_Orientada_Objetos.Relacoes_Heranca_Associacao_Interface.Heranca.Exercicio02_Pt02;

public class ClasseFilha2 extends ClasseMae{

    @Override // Realizando Sobrescrita
    void metodo1() {
        System.out.println("Método 1 da Classe Filha 2");
    }

    @Override // Realizando Sobrescrita
    void metodo2() {
        System.out.println("Método 2 da Classe Filha 2");
    }
}
