package Programacao_Orientada_Objetos.Relacoes_Heranca_Associacao_Interface.Heranca.Exercicio02_Pt02;

public class ClasseMae {

    void metodo1() {
        System.out.println("Método 1 da Classe Mãe");
    }

    void metodo2() {
        System.out.println("Método 2 da Classe Mãe");
    }
}
