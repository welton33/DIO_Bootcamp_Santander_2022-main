package Programacao_Orientada_Objetos.Relacoes_Heranca_Associacao_Interface.Heranca.Exercicio01;

public class Moto extends Veiculo{
}
