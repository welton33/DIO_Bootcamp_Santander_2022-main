package Programacao_Orientada_Objetos.Relacoes_Heranca_Associacao_Interface.Heranca.Exercicio02_Pt01;

public class Gerente extends  Funcionario{
}
