package Programacao_Orientada_Objetos.Relacoes_Heranca_Associacao_Interface.Associacao;

public class Endereco {
}
