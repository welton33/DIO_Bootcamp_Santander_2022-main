package Programacao_Orientada_Objetos.Relacoes_Heranca_Associacao_Interface.Associacao;

// Associação Comportamental -> Dependência
// O método da classe depende de outra neste caso Cupom

public class Compra {

    void finalizar(Cupom cupom) {

    }
}
