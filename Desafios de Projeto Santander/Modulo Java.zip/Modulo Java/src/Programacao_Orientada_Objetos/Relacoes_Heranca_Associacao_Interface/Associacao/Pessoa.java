package Programacao_Orientada_Objetos.Relacoes_Heranca_Associacao_Interface.Associacao;

// Associação Estrutural -> Composição
// Se a Pessoa deixar de existir o endereço deixa de existir também

public class Pessoa {

    Endereco endereco;

}
