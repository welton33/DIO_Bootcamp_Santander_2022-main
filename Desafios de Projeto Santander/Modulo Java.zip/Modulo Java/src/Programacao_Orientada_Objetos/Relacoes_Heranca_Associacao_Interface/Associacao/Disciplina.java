package Programacao_Orientada_Objetos.Relacoes_Heranca_Associacao_Interface.Associacao;

// Associação Estrutural -> Agregação
// Se a Disciplina deixar de existir não necessariamente o Aluno deixa de existir, podendo está ligado a outra.

public class Disciplina {

    Aluno aluno;
}
