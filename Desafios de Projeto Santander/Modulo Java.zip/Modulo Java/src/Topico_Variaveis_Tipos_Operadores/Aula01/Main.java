package Topico_Variaveis_Tipos_Operadores.Aula01;

/**
 * Classe de exemplo para o exercício da Aula 1 de Variáveis, Tipos de Dado e Operadores aritméticos.
 */
public class Main {

    public static void main(String[] args) {

        int i;
        //int i;
        int I;
        //int 1a;
        int _1a; // fere as boas práticas
        int $aq; // fere as boas práticas

        i = 5;
        I = 10;
        _1a = 20;
        $aq = 7;

        final int j = 10;
        //j = 15;
        int asrn24678md; // fere as boas práticas
        //int asrn246 78md;
        int asrn2$4678_md = 10; // fere as boas práticas
        //int asrn2$46%78_md = 10;

        asrn24678md = 100;
        asrn2$4678_md = 10;

        int quantidadeProduto = 50;
        //int QuantidadeProduto; // fere as boas práticas
        final int NUMERO_TENTATIVAS = 5;
        //final int numeroTentativas = 5; // fere as boas práticas
        int QUANTIDADE_OPCOES = 25; // fere as boas práticas
        //int qtdProd; // fere as boas práticas

        System.out.println("Grupo 1");
        System.out.println(i);
        System.out.println(I);
        System.out.println(_1a);
        System.out.println($aq);

        System.out.println("\n");

        System.out.println("Grupo 2");
        System.out.println(j);
        System.out.println(asrn24678md);
        System.out.println(asrn2$4678_md);

        System.out.println("\n");

        System.out.println("Grupo 3");
        System.out.println(quantidadeProduto);
        System.out.println(NUMERO_TENTATIVAS);
        System.out.println(QUANTIDADE_OPCOES);

    }
}
